// ─── Shared types, data and helpers for the Agent Architecture diagram ────────

export interface NodeDef {
  id: string;
  label: string;
  description: string;
  aliases?: string[];
}

export interface LayerDef {
  id: string;
  label: string;
  subtitle: string;
  cssColor: string;   // CSS custom property for use inside style=""
  hexColor: string;   // Literal hex for SVG attributes that can't use var()
  nodes: NodeDef[];
}

export interface Edge {
  from: string;
  to: string;
  label: string;
}

// ─── Layers ───────────────────────────────────────────────────────────────────

export const LAYERS: LayerDef[] = [
  {
    id: 'interfaces',
    label: 'Interfaces',
    subtitle: 'How builders interact',
    cssColor: 'var(--primary)',
    hexColor: '#F96E5B',
    nodes: [
      {
        id: 'chat',
        label: 'Chat',
        description:
          'The primary conversational surface for interacting with AI. Natural language in, structured responses out — the most accessible entry point for most users.',
      },
      {
        id: 'slash-commands',
        label: 'Slash Commands',
        description:
          'Shortcut-style commands (e.g. /summarize, /search) that trigger specific behaviors instantly without a full conversation. Ideal for power users who know what they want.',
        aliases: ['Commands', 'Shortcuts', 'Actions'],
      },
      {
        id: 'terminal',
        label: 'Terminal',
        description:
          'CLI-based interface giving developers direct, scriptable, composable access to AI capabilities. Ideal for automation pipelines and technical workflows.',
      },
    ],
  },
  {
    id: 'experiences',
    label: 'Experiences',
    subtitle: 'Packaged behaviors people create & use',
    cssColor: 'var(--chart-2)',
    hexColor: '#5953BF',
    nodes: [
      {
        id: 'custom-assistants',
        label: 'Custom Assistants',
        description:
          'Personalized AI configurations combining custom instructions, a persona, specific tools, and memory settings. Built once, deployed repeatedly for a focused purpose.',
        aliases: ['Custom GPTs', 'Bots', 'Projects', 'Assistants'],
      },
      {
        id: 'workspace',
        label: 'Workspace / Collab',
        description:
          'Shared AI-powered spaces where multiple users work with the same context, artifacts, and memory across sessions. Enables team-level AI coordination.',
        aliases: ['Cowork', 'Team Spaces', 'Shared Projects'],
      },
      {
        id: 'app-workflow',
        label: 'App / Workflow',
        description:
          'A task-focused wrapper around an assistant, designed to complete a specific, repeatable job — often with a structured UI, defined inputs, and expected outputs.',
      },
    ],
  },
  {
    id: 'orchestration',
    label: 'Orchestration',
    subtitle: 'How work gets planned, routed & executed',
    cssColor: 'var(--chart-3)',
    hexColor: '#00B5A5',
    nodes: [
      {
        id: 'agents',
        label: 'Agents',
        description:
          'Autonomous executors that operate in a loop: plan → act → observe → iterate. They decide which tools to call and when, driving multi-step tasks to completion without per-step human input.',
      },
      {
        id: 'skills-tools',
        label: 'Skills / Tools',
        description:
          'Discrete capabilities an agent can invoke: web search, code execution, calendar access, database queries, email sending, and more. Each tool has a defined interface.',
        aliases: ['Tools', 'Capabilities', 'Plugins'],
      },
      {
        id: 'tool-calling',
        label: 'Tool Calling',
        description:
          'The structured mechanism by which a model requests external function execution. The model outputs a call spec (name + args); the runtime executes it and returns a result.',
        aliases: ['Function Calling', 'Actions', 'Tool Use'],
      },
      {
        id: 'routing',
        label: 'Routing / Dispatcher',
        description:
          'Decides which agent, model, or skill should handle a given request. May use rules, intent classification, or a separate LLM call to route appropriately.',
      },
      {
        id: 'memory',
        label: 'Memory',
        description:
          'Storage of context beyond a single turn. Session memory is ephemeral (lost after the conversation); persistent memory survives across sessions and can be retrieved later.',
      },
      {
        id: 'guardrails',
        label: 'Guardrails / Policies',
        description:
          'Rules and constraints that define what the agent is allowed to do, say, or access. Enforced at inference time to prevent misuse, errors, or policy violations.',
      },
      {
        id: 'evals',
        label: 'Evals / Testing',
        description:
          'Automated test suites that measure agent correctness, quality, and regression over time. Essential for safely shipping improvements to prompts, tools, or models.',
      },
      {
        id: 'observability',
        label: 'Observability',
        description:
          'Detailed logs of every step in an agent run — which tools were called, what the model decided, latency at each step, token cost, and success or failure. The primary debugging surface.',
        aliases: ['Traces', 'Logging'],
      },
    ],
  },
  {
    id: 'foundations',
    label: 'Foundations',
    subtitle: 'Models, data & execution infrastructure',
    cssColor: 'var(--chart-4)',
    hexColor: '#786ECE',
    nodes: [
      {
        id: 'llms',
        label: 'LLMs / Models',
        description:
          'The large language models that power inference — the core reasoning engine. Different models offer different capability/cost/latency tradeoffs. Choose based on task requirements.',
        aliases: ['Models', 'Foundation Models', 'AI Models'],
      },
      {
        id: 'context-window',
        label: 'Context Window',
        description:
          'The active working memory available to the model per request. Everything the model "sees" at once: system prompt, conversation history, retrieved docs, tool outputs, and instructions.',
      },
      {
        id: 'tokens',
        label: 'Tokens',
        description:
          'The atomic unit of text processed by a model. Drives cost calculations, determines throughput limits, and directly constrains what fits in the context window.',
      },
      {
        id: 'retrieval',
        label: 'Retrieval / RAG',
        description:
          "Fetches relevant documents at inference time to ground the model in up-to-date, proprietary, or specialized knowledge it wasn't trained on. Reduces hallucination on domain-specific topics.",
        aliases: ['RAG', 'Retrieval-Augmented Generation', 'Semantic Search'],
      },
      {
        id: 'embeddings',
        label: 'Embeddings',
        description:
          'Dense vector representations of text that capture semantic meaning, enabling similarity search. "Find content closest in meaning to this query" — the engine behind RAG.',
      },
      {
        id: 'knowledge-base',
        label: 'Knowledge Base',
        description:
          "The indexed repositories — documents, databases, wikis, code — that retrieval draws from. Represents an organization's proprietary knowledge made accessible to AI.",
        aliases: ['Data Sources', 'Vector Store', 'Document Store'],
      },
      {
        id: 'runtime-sandbox',
        label: 'Runtime / Sandbox',
        description:
          'Secure, isolated execution environment where code and tool actions actually run. Prevents malicious or accidental damage from agent-generated code or misconfigured tools.',
        aliases: ['Code Interpreter', 'Execution Environment'],
      },
      {
        id: 'integrations-apis',
        label: 'Integrations / APIs',
        description:
          'Connections to external services — CRMs, calendars, databases, SaaS tools, internal APIs — that agents can read from or write to via tool calls.',
        aliases: ['Connectors', 'Plugins', 'Actions', 'APIs'],
      },
      {
        id: 'auth-permissions',
        label: 'Auth / Permissions',
        description:
          'Access control determining what data a user can access, what tools an agent is allowed to call, and enforcing least-privilege principles across the system.',
        aliases: ['IAM', 'Access Control', 'OAuth', 'RBAC'],
      },
    ],
  },
];

// ─── Edges ────────────────────────────────────────────────────────────────────

export const EDGES: Edge[] = [
  // Interface → Experience
  { from: 'chat', to: 'custom-assistants', label: 'invokes' },
  { from: 'chat', to: 'workspace', label: 'invokes' },
  { from: 'slash-commands', to: 'custom-assistants', label: 'invokes' },
  { from: 'slash-commands', to: 'workspace', label: 'invokes' },
  { from: 'terminal', to: 'custom-assistants', label: 'invokes' },
  // Experience → Orchestration
  { from: 'custom-assistants', to: 'agents', label: 'configures' },
  { from: 'custom-assistants', to: 'memory', label: 'sets up' },
  { from: 'custom-assistants', to: 'skills-tools', label: 'equips' },
  { from: 'custom-assistants', to: 'guardrails', label: 'applies' },
  { from: 'workspace', to: 'memory', label: 'shares via' },
  { from: 'workspace', to: 'agents', label: 'coordinates' },
  { from: 'app-workflow', to: 'agents', label: 'triggers' },
  { from: 'app-workflow', to: 'routing', label: 'uses' },
  // Orchestration → Foundations
  { from: 'agents', to: 'llms', label: 'uses' },
  { from: 'agents', to: 'context-window', label: 'fills' },
  { from: 'tool-calling', to: 'runtime-sandbox', label: 'executes in' },
  { from: 'tool-calling', to: 'integrations-apis', label: 'calls' },
  { from: 'routing', to: 'llms', label: 'dispatches to' },
  { from: 'memory', to: 'knowledge-base', label: 'persists to' },
  { from: 'guardrails', to: 'auth-permissions', label: 'enforces' },
  { from: 'evals', to: 'llms', label: 'benchmarks' },
  { from: 'observability', to: 'llms', label: 'traces' },
  { from: 'skills-tools', to: 'runtime-sandbox', label: 'runs in' },
  { from: 'skills-tools', to: 'integrations-apis', label: 'uses' },
  // Foundation → Foundation
  { from: 'retrieval', to: 'knowledge-base', label: 'pulls from' },
  { from: 'retrieval', to: 'embeddings', label: 'uses' },
  { from: 'embeddings', to: 'knowledge-base', label: 'indexes' },
  { from: 'context-window', to: 'tokens', label: 'measured in' },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

export function findLayerForNode(nodeId: string): LayerDef | undefined {
  return LAYERS.find((l) => l.nodes.some((n) => n.id === nodeId));
}

export function findNodeById(nodeId: string): NodeDef | undefined {
  for (const layer of LAYERS) {
    const node = layer.nodes.find((n) => n.id === nodeId);
    if (node) return node;
  }
  return undefined;
}

export function getConnectedIds(nodeId: string | null): Set<string> {
  const ids = new Set<string>();
  if (!nodeId) return ids;
  ids.add(nodeId);
  EDGES.forEach((e) => {
    if (e.from === nodeId) ids.add(e.to);
    if (e.to === nodeId) ids.add(e.from);
  });
  return ids;
}

export function isCrossLayerEdge(edge: Edge): boolean {
  const from = findLayerForNode(edge.from);
  const to = findLayerForNode(edge.to);
  return !!from && !!to && from.id !== to.id;
}
