import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Info, Layers, Network } from 'lucide-react';
import {
  LAYERS,
  EDGES,
  findLayerForNode,
  getConnectedIds,
  isCrossLayerEdge,
  type LayerDef,
} from './diagram-data';
import { DiagramDetailPanel } from './DiagramDetailPanel';
import { HubSpokeView } from './HubSpokeView';

// ─── Types ────────────────────────────────────────────────────────────────────

type ViewMode = 'layered' | 'hub-spoke';

interface RenderedPath {
  d: string;
  label: string;
  labelX: number;
  labelY: number;
  hexColor: string;
  layerId: string;
}

// ─── Bezier helper ────────────────────────────────────────────────────────────

function getBezierPath(x1: number, y1: number, x2: number, y2: number): string {
  const dy = y2 - y1;
  const cp = Math.max(Math.abs(dy) * 0.55, 40);
  return `M ${x1.toFixed(1)} ${y1.toFixed(1)} C ${x1.toFixed(1)} ${(y1 + cp).toFixed(1)}, ${x2.toFixed(1)} ${(y2 - cp).toFixed(1)}, ${x2.toFixed(1)} ${y2.toFixed(1)}`;
}

// ─── View Toggle ──────────────────────────────────────────────────────────────

interface ViewToggleProps {
  viewMode: ViewMode;
  onChange: (v: ViewMode) => void;
}

function ViewToggle({ viewMode, onChange }: ViewToggleProps) {
  return (
    <div
      style={{
        display: 'flex',
        background: 'var(--secondary)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius)',
        padding: '3px',
        gap: '2px',
      }}
    >
      {(
        [
          { id: 'layered', Icon: Layers, label: 'Layered' },
          { id: 'hub-spoke', Icon: Network, label: 'Hub & Spoke' },
        ] as const
      ).map(({ id, Icon, label }) => {
        const isActive = viewMode === id;
        return (
          <button
            key={id}
            onClick={() => onChange(id)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '6px 14px',
              borderRadius: 'calc(var(--radius) - 2px)',
              border: 'none',
              cursor: 'pointer',
              background: isActive ? 'var(--background)' : 'transparent',
              color: isActive ? 'var(--foreground)' : 'var(--muted-foreground)',
              boxShadow: isActive ? 'var(--elevation-sm)' : 'none',
              transition: 'all 0.15s',
              whiteSpace: 'nowrap',
            }}
          >
            <Icon size={14} style={{ flexShrink: 0 }} />
            <label
              style={{
                cursor: 'pointer',
                color: 'inherit',
                fontWeight: isActive ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
              }}
            >
              {label}
            </label>
          </button>
        );
      })}
    </div>
  );
}

// ─── Layered View ─────────────────────────────────────────────────────────────

interface LayeredViewProps {
  selectedId: string | null;
  onSelectId: (id: string | null) => void;
}

function LayeredView({ selectedId, onSelectId }: LayeredViewProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const nodeRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const [paths, setPaths] = useState<RenderedPath[]>([]);
  const [svgSize, setSvgSize] = useState({ w: 0, h: 0 });

  const connectedIds = getConnectedIds(selectedId);

  const recalculate = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;

    const cRect = container.getBoundingClientRect();
    const scrollTop = container.scrollTop;

    setSvgSize({ w: container.scrollWidth, h: container.scrollHeight });

    if (!selectedId) {
      setPaths([]);
      return;
    }

    const relatedEdges = EDGES.filter(
      (e) => (e.from === selectedId || e.to === selectedId) && isCrossLayerEdge(e)
    );

    const newPaths: RenderedPath[] = [];
    for (const edge of relatedEdges) {
      const fromEl = nodeRefs.current[edge.from];
      const toEl = nodeRefs.current[edge.to];
      if (!fromEl || !toEl) continue;

      const fromRect = fromEl.getBoundingClientRect();
      const toRect = toEl.getBoundingClientRect();

      const x1 = fromRect.left - cRect.left + fromRect.width / 2;
      const y1 = fromRect.bottom - cRect.top + scrollTop;
      const x2 = toRect.left - cRect.left + toRect.width / 2;
      const y2 = toRect.top - cRect.top + scrollTop;

      const fromLayer = findLayerForNode(edge.from)!;

      newPaths.push({
        d: getBezierPath(x1, y1, x2, y2),
        label: edge.label,
        labelX: (x1 + x2) / 2,
        labelY: (y1 + y2) / 2,
        hexColor: fromLayer.hexColor,
        layerId: fromLayer.id,
      });
    }

    setPaths(newPaths);
  }, [selectedId]);

  useEffect(() => {
    recalculate();
  }, [recalculate]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    container.addEventListener('scroll', recalculate);
    window.addEventListener('resize', recalculate);
    return () => {
      container.removeEventListener('scroll', recalculate);
      window.removeEventListener('resize', recalculate);
    };
  }, [recalculate]);

  return (
    <div
      ref={containerRef}
      style={{
        flex: 1,
        overflowY: 'auto',
        position: 'relative',
        padding: '28px 36px',
      }}
    >
      {/* SVG connection overlay */}
      {selectedId && (
        <svg
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: svgSize.w || '100%',
            height: svgSize.h || '100%',
            pointerEvents: 'none',
            zIndex: 10,
          }}
        >
          <defs>
            <style>{`
              @keyframes marchPath { to { stroke-dashoffset: -12; } }
              .flow-line { stroke-dasharray: 7 4; animation: marchPath 0.7s linear infinite; }
            `}</style>
            {LAYERS.map((layer) => (
              <marker
                key={layer.id}
                id={`arrow-${layer.id}`}
                viewBox="0 0 10 10"
                refX="9"
                refY="5"
                markerWidth="7"
                markerHeight="7"
                orient="auto-start-reverse"
              >
                <path d="M 0 1 L 9 5 L 0 9 z" fill={layer.hexColor} />
              </marker>
            ))}
          </defs>

          {paths.map((path, i) => (
            <g key={i}>
              <path
                d={path.d}
                fill="none"
                stroke={path.hexColor}
                strokeWidth={6}
                strokeOpacity={0.12}
                strokeLinecap="round"
              />
              <path
                d={path.d}
                fill="none"
                stroke={path.hexColor}
                strokeWidth={2}
                strokeOpacity={0.85}
                strokeLinecap="round"
                markerEnd={`url(#arrow-${path.layerId})`}
                className="flow-line"
              />
              <g transform={`translate(${path.labelX.toFixed(1)}, ${path.labelY.toFixed(1)})`}>
                <rect
                  x={-28} y={-10} width={56} height={20} rx={4}
                  fill="var(--secondary)"
                  stroke={path.hexColor}
                  strokeWidth={1}
                  opacity={0.95}
                />
                <text
                  textAnchor="middle"
                  dominantBaseline="middle"
                  style={{ fill: 'var(--foreground)' }}
                  fontSize="10"
                  fontFamily="Inter, sans-serif"
                  fontWeight="600"
                >
                  {path.label}
                </text>
              </g>
            </g>
          ))}
        </svg>
      )}

      {/* Layer stack */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
          position: 'relative',
          zIndex: 1,
        }}
      >
        {LAYERS.map((layer, layerIndex) => (
          <div key={layer.id}>
            {/* Layer card */}
            <div
              style={{
                borderRadius: 'var(--radius-card)',
                border: '1px solid var(--border)',
                overflow: 'hidden',
                background: 'rgba(255,255,255,0.02)',
              }}
            >
              {/* Layer header */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  padding: '12px 18px',
                  borderBottom: '1px solid var(--border)',
                  borderLeft: `4px solid ${layer.cssColor}`,
                  background: 'rgba(255,255,255,0.03)',
                }}
              >
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: '10px' }}>
                    <h3 style={{ margin: 0, color: 'var(--foreground)' }}>{layer.label}</h3>
                    <label style={{ color: 'var(--muted-foreground)' }}>{layer.subtitle}</label>
                  </div>
                </div>
                <div
                  style={{
                    background: `${layer.hexColor}55`,
                    border: `1px solid ${layer.hexColor}88`,
                    borderRadius: 'var(--radius)',
                    padding: '2px 10px',
                  }}
                >
                  <label style={{ color: 'var(--foreground)' }}>
                    Layer {layerIndex + 1}
                  </label>
                </div>
              </div>

              {/* Node chips */}
              <div
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '8px',
                  padding: '14px 18px',
                }}
              >
                {layer.nodes.map((node) => {
                  const isSelected = selectedId === node.id;
                  const isConnected = connectedIds.has(node.id) && !isSelected;
                  const isDimmed =
                    selectedId !== null && !connectedIds.has(node.id) && !isSelected;
                  const isHovered = hoveredId === node.id;

                  return (
                    <motion.div
                      key={node.id}
                      ref={(el) => {
                        nodeRefs.current[node.id] = el;
                      }}
                      onClick={() => onSelectId(node.id === selectedId ? null : node.id)}
                      onMouseEnter={() => setHoveredId(node.id)}
                      onMouseLeave={() => setHoveredId(null)}
                      animate={{
                        opacity: isDimmed ? 0.3 : 1,
                        scale: isSelected ? 1.03 : 1,
                      }}
                      transition={{ duration: 0.15 }}
                      style={{
                        cursor: 'pointer',
                        borderRadius: 'var(--radius-card)',
                        padding: '9px 13px',
                        minWidth: '140px',
                        maxWidth: '220px',
                        userSelect: 'none',
                        background: isSelected
                          ? `${layer.hexColor}1A`
                          : isConnected
                          ? `${layer.hexColor}0D`
                          : 'var(--secondary)',
                        border: isSelected
                          ? `2px solid ${layer.cssColor}`
                          : isConnected
                          ? `1.5px solid ${layer.hexColor}77`
                          : '1px solid var(--border)',
                        boxShadow: isSelected
                          ? `0 0 0 3px ${layer.hexColor}22, var(--elevation-md)`
                          : isHovered
                          ? 'var(--elevation-md)'
                          : 'var(--elevation-sm)',
                        transition: 'background 0.15s, border 0.15s, box-shadow 0.15s',
                      }}
                    >
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '7px',
                          marginBottom: node.aliases ? '3px' : '0',
                        }}
                      >
                        <div
                          style={{
                            width: '7px',
                            height: '7px',
                            borderRadius: '50%',
                            background: layer.cssColor,
                            flexShrink: 0,
                            opacity: isSelected || isConnected ? 1 : 0.65,
                          }}
                        />
                        <p
                          style={{
                            margin: 0,
                            fontSize: 'var(--text-sm)',
                            fontWeight: 'var(--font-weight-medium)',
                            color: 'var(--foreground)',
                            lineHeight: 1.3,
                          }}
                        >
                          {node.label}
                        </p>
                      </div>
                      {node.aliases && (
                        <label
                          style={{
                            display: 'block',
                            marginLeft: '14px',
                            color: 'var(--muted-foreground)',
                            fontSize: 'var(--text-sm)',
                            opacity: 0.65,
                          }}
                        >
                          {node.aliases.slice(0, 2).join(' · ')}
                        </label>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* Divider arrow */}
            {layerIndex < LAYERS.length - 1 && (
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'center',
                  padding: '5px 0',
                  opacity: 0.22,
                }}
              >
                <svg width="16" height="16" viewBox="0 0 16 16">
                  <line x1="8" y1="0" x2="8" y2="10" stroke="var(--foreground)" strokeWidth="1.5" />
                  <path
                    d="M 4 7 L 8 12 L 12 7"
                    fill="none"
                    stroke="var(--foreground)"
                    strokeWidth="1.5"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Root Component ───────────────────────────────────────────────────────────

export function AgentDiagram() {
  const [viewMode, setViewMode] = useState<ViewMode>('layered');
  const [selectedId, setSelectedId] = useState<string | null>(null);

  // Clear selection on view switch so stale paths don't linger
  const handleViewChange = (v: ViewMode) => {
    setSelectedId(null);
    setViewMode(v);
  };

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        background: 'var(--background)',
        color: 'var(--foreground)',
        overflow: 'hidden',
        fontFamily: 'Inter, sans-serif',
      }}
    >
      {/* ── Header ── */}
      <div
        style={{
          flexShrink: 0,
          padding: '24px 36px 20px',
          borderBottom: '1px solid var(--border)',
          display: 'flex',
          alignItems: 'center',
          gap: '24px',
          flexWrap: 'wrap',
        }}
      >
        {/* Title + subtitle */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <h2 style={{ marginBottom: '4px' }}>Agent Architecture</h2>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Info size={13} style={{ color: 'var(--muted-foreground)', flexShrink: 0 }} />
            <p style={{ margin: 0, color: 'var(--muted-foreground)' }}>
              {viewMode === 'layered'
                ? 'Click a node to highlight its connections across layers'
                : 'Click a node on the ring to explore its connections'}
            </p>
          </div>
        </div>

        {/* Layer legend */}
        <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap', alignItems: 'center' }}>
          {LAYERS.map((layer) => (
            <div key={layer.id} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <div
                style={{
                  width: '9px',
                  height: '9px',
                  borderRadius: '50%',
                  background: layer.cssColor,
                  flexShrink: 0,
                }}
              />
              <label style={{ color: 'var(--foreground)', fontWeight: 'var(--font-weight-medium)' }}>
                {layer.label}
              </label>
            </div>
          ))}
        </div>

        {/* View toggle */}
        <ViewToggle viewMode={viewMode} onChange={handleViewChange} />
      </div>

      {/* ── Body ── */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Main view */}
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          <AnimatePresence mode="wait">
            {viewMode === 'layered' ? (
              <motion.div
                key="layered"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18 }}
                style={{ flex: 1, display: 'flex', overflow: 'hidden' }}
              >
                <LayeredView selectedId={selectedId} onSelectId={setSelectedId} />
              </motion.div>
            ) : (
              <motion.div
                key="hub-spoke"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18 }}
                style={{ flex: 1, display: 'flex', overflow: 'hidden' }}
              >
                <HubSpokeView selectedId={selectedId} onSelectId={setSelectedId} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Shared detail panel */}
        <DiagramDetailPanel selectedId={selectedId} onSelectId={setSelectedId} />
      </div>

      {/* ── Empty state toast ── */}
      <AnimatePresence>
        {!selectedId && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.2 }}
            style={{
              position: 'fixed',
              bottom: '24px',
              left: '50%',
              transform: 'translateX(-50%)',
              background: 'var(--secondary)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius)',
              padding: '10px 20px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              pointerEvents: 'none',
              zIndex: 50,
              boxShadow: 'var(--elevation-md)',
            }}
          >
            <Info size={13} style={{ color: 'var(--muted-foreground)', flexShrink: 0 }} />
            <label style={{ color: 'var(--muted-foreground)' }}>
              Select a node to explore its connections and details
            </label>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
