import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ArrowRight, ArrowLeft } from 'lucide-react';
import {
  EDGES,
  LAYERS,
  findLayerForNode,
  findNodeById,
  type LayerDef,
  type NodeDef,
} from './diagram-data';

// ─── Detail Panel ─────────────────────────────────────────────────────────────

interface DiagramDetailPanelProps {
  selectedId: string | null;
  onSelectId: (id: string | null) => void;
}

export function DiagramDetailPanel({ selectedId, onSelectId }: DiagramDetailPanelProps) {
  const selectedNode = selectedId ? findNodeById(selectedId) : null;
  const selectedLayer = selectedId ? findLayerForNode(selectedId) : null;
  const outgoingEdges = selectedId ? EDGES.filter((e) => e.from === selectedId) : [];
  const incomingEdges = selectedId ? EDGES.filter((e) => e.to === selectedId) : [];

  return (
    <AnimatePresence>
      {selectedNode && selectedLayer && (
        <motion.div
          key="panel"
          initial={{ x: 320, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 320, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          style={{
            width: '300px',
            flexShrink: 0,
            background: 'var(--secondary)',
            borderLeft: '1px solid var(--border)',
            display: 'flex',
            flexDirection: 'column',
            overflowY: 'auto',
          }}
        >
          {/* Panel Header */}
          <div
            style={{
              padding: '20px 20px 16px',
              borderBottom: '1px solid var(--border)',
              position: 'sticky',
              top: 0,
              background: 'var(--secondary)',
              zIndex: 1,
            }}
          >
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'flex-start',
                marginBottom: '10px',
              }}
            >
              {/* Layer badge */}
              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px',
                  background: `${selectedLayer.hexColor}55`,
                  border: `1px solid ${selectedLayer.hexColor}88`,
                  borderRadius: 'var(--radius)',
                  padding: '3px 10px',
                }}
              >
                <div
                  style={{
                    width: '7px',
                    height: '7px',
                    borderRadius: '50%',
                    background: selectedLayer.cssColor,
                    flexShrink: 0,
                  }}
                />
                <label
                  style={{
                    color: 'var(--foreground)',
                    fontWeight: 'var(--font-weight-medium)',
                    cursor: 'default',
                  }}
                >
                  {selectedLayer.label}
                </label>
              </div>

              <button
                onClick={() => onSelectId(null)}
                style={{
                  background: 'transparent',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius)',
                  cursor: 'pointer',
                  color: 'var(--muted-foreground)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '4px',
                  flexShrink: 0,
                }}
              >
                <X size={16} />
              </button>
            </div>

            <h3 style={{ margin: 0, color: 'var(--foreground)' }}>
              {selectedNode.label}
            </h3>
          </div>

          {/* Panel Body */}
          <div
            style={{
              padding: '20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '24px',
            }}
          >
            {/* Description */}
            <p style={{ margin: 0, color: 'var(--muted-foreground)', lineHeight: 1.65 }}>
              {selectedNode.description}
            </p>

            {/* Aliases */}
            {selectedNode.aliases && selectedNode.aliases.length > 0 && (
              <div>
                <SectionLabel>Also known as</SectionLabel>
                <div
                  style={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    gap: '6px',
                    marginTop: '8px',
                  }}
                >
                  {selectedNode.aliases.map((alias) => (
                    <span
                      key={alias}
                      style={{
                        background: 'var(--background)',
                        border: '1px solid var(--border)',
                        borderRadius: 'var(--radius)',
                        padding: '3px 10px',
                        fontSize: 'var(--text-sm)',
                        color: 'var(--muted-foreground)',
                      }}
                    >
                      {alias}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Outgoing connections */}
            {outgoingEdges.length > 0 && (
              <div>
                <SectionLabel>Connects to</SectionLabel>
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '6px',
                    marginTop: '8px',
                  }}
                >
                  {outgoingEdges.map((edge) => {
                    const targetNode = findNodeById(edge.to);
                    const targetLayer = findLayerForNode(edge.to);
                    if (!targetNode) return null;
                    return (
                      <ConnectionCard
                        key={edge.to}
                        node={targetNode}
                        layer={targetLayer}
                        relationLabel={edge.label}
                        direction="out"
                        onClick={() => onSelectId(edge.to)}
                      />
                    );
                  })}
                </div>
              </div>
            )}

            {/* Incoming connections */}
            {incomingEdges.length > 0 && (
              <div>
                <SectionLabel>Receives from</SectionLabel>
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '6px',
                    marginTop: '8px',
                  }}
                >
                  {incomingEdges.map((edge) => {
                    const sourceNode = findNodeById(edge.from);
                    const sourceLayer = findLayerForNode(edge.from);
                    if (!sourceNode) return null;
                    return (
                      <ConnectionCard
                        key={edge.from}
                        node={sourceNode}
                        layer={sourceLayer}
                        relationLabel={edge.label}
                        direction="in"
                        onClick={() => onSelectId(edge.from)}
                      />
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <label
      style={{
        color: 'var(--muted)',
        fontSize: 'var(--text-sm)',
        fontWeight: 'var(--font-weight-medium)',
        textTransform: 'uppercase',
        letterSpacing: '0.07em',
        display: 'block',
      }}
    >
      {children}
    </label>
  );
}

interface ConnectionCardProps {
  node: NodeDef;
  layer: LayerDef | undefined;
  relationLabel: string;
  direction: 'in' | 'out';
  onClick: () => void;
}

function ConnectionCard({
  node,
  layer,
  relationLabel,
  direction,
  onClick,
}: ConnectionCardProps) {
  const [hovered, setHovered] = useState(false);

  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? 'var(--background)' : 'rgba(255,255,255,0.03)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius)',
        padding: '9px 12px',
        cursor: 'pointer',
        textAlign: 'left',
        width: '100%',
        display: 'block',
        transition: 'background 0.12s',
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          marginBottom: '2px',
        }}
      >
        {direction === 'in' ? (
          <ArrowLeft
            size={11}
            style={{ color: layer?.cssColor || 'var(--muted)', flexShrink: 0 }}
          />
        ) : (
          <ArrowRight
            size={11}
            style={{ color: layer?.cssColor || 'var(--muted)', flexShrink: 0 }}
          />
        )}
        <label
          style={{
            color: 'var(--muted-foreground)',
            fontSize: 'var(--text-sm)',
            opacity: 0.8,
            cursor: 'pointer',
          }}
        >
          {relationLabel}
        </label>
      </div>
      <div style={{ paddingLeft: '17px' }}>
        <p
          style={{
            margin: 0,
            color: 'var(--foreground)',
            fontSize: 'var(--text-sm)',
            fontWeight: 'var(--font-weight-medium)',
            lineHeight: 1.3,
          }}
        >
          {node.label}
        </p>
        {layer && (
          <label
            style={{
              color: 'var(--muted-foreground)',
              fontSize: 'var(--text-sm)',
              opacity: 0.85,
              cursor: 'pointer',
            }}
          >
            {layer.label}
          </label>
        )}
      </div>
    </button>
  );
}
